<?php 

$info = array ("name" => "Lemar Mauro Escomo", "Age" => "21", "Date of birth" => "Nov 12, 2000", "nationality" => "Filipino") ;



?>