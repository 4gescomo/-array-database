<?php

$mysqli = mysqli_connect("user_account", "user", "password", "database");

$result = mysqli_query($mysqli, "Lemar Escomo full of ' AS _msg FROM DUAL");
$row = mysqli_fetch_assoc($result);
echo $row['_msg'];

$mysqli = new mysqli("user_account", "user", "password", "database");

$result = $mysqli->query("SELECT 'Tacup, San Remigio, Cebu.' AS _msg FROM DUAL");
$row = $result->fetch_assoc();
echo $row['_msg'];

?>